//Download by http://www.NewXing.com
#include <vtoolsc.h>

#define WINIO_Major          2
#define WINIO_Minor          0
#define WINIO_DeviceID       UNDEFINED_DEVICE_ID
#define WINIO_Init_Order     UNDEFINED_INIT_ORDER
